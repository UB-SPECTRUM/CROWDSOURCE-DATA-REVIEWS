<html>
<head>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<?php include "header.php";?>   
<div class="jumbotron">
  <h1 class="display-4">Sorry</h1>
  <p class="lead">Oops! We can't find the page you are looking for<br> try searching or, <a href="#">Go back to our home page</a></p>

  <hr class="my-4">
  <a class="btn btn-primary btn" href="#" role="button">Contact Us</a>
  </p>
</div>
<?php include "footer.php";?> 
</body>
</html>
