<?php
    session_start();
    if(isset($_GET['datasetid']))
    $_SESSION['did']=$_GET['datasetid'];
    if(isset($_GET['datasetname']))
    $_SESSION['dname']=$_GET['datasetname'];
    if(isset($_GET['datasetdescription']))
    $_SESSION['ddes']=$_GET['datasetdescription'];
    $did=$_SESSION['did'];
    $dname=$_SESSION['dname'];
    $ddes=$_SESSION['ddes'];
?>

<html>
<head>
    <link rel = "stylesheet/css" href="css/bootstrap.css" > 
    <link rel = "stylesheet/css" href="css/header.css" >      
</head>
<body>
<?php include"header.php";?>
<div id =input_padding></div>
<div class="container">
    <h2><?php echo $dname ?> </h2>

    <p><?php echo $ddes ?></p>
    <p>Want to review ? </p>
    

        <form method="GET" action="">
            <div id="mail">
                <label>Please enter your UBIT Name: </label>
                <input type="text" id="ubitname" name="ubitname"  />
                <input type="submit" name="Publish" value="Enter">
            </div>
        </form>

 
  <div class="modal" id="myModal">
        <div class="modal-dialog">
        <div class="modal-content">
        
                
                 <div class="modal-header">
                <h4 class="modal-title">Please enter the token send to your mail.</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="GET" action="">
                    <div class="modal-body">
                        <input type="text" name="token" placeholder="Valid Token">
                        <input type="submit" class="btn btn-primary" name="save" value="Submit"/>
                    </div>
                </form>
            </div>
        </div>
    </div>

           
   
</div>

<?php
require 'PHPMailerAutoload.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "csdr";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    //please try again later
}
 else{
     
        if (isset($_GET['Publish'])) {
        $ubitname=$_GET['ubitname'];
        $_SESSION['ubitname']=$ubitname;
      //  $ubname=$_SESSION['ubitname'];
        $ubitmail=$ubitname.'@buffalo.edu';
        $Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $token= substr(str_shuffle($Generator),0,5);
        $ubittoken= $ubitname.$token;
    
        $sql = "INSERT INTO tbl_student_signup VALUES ('$ubitname','$token','$ubitmail','$ubittoken')";
         if($conn->query($sql)){
        //send mail
            $mail = new PHPMailer;

            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'nallusowmith6@gmail.com';                 // SMTP username
            $mail->Password = 'anitha1995';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted

            $mail->From = 'nallusowmith6@gmail.com';
            $mail->FromName = 'Ub Spectrum';
            $mail->addAddress(''.$ubitmail);     
            $mail->WordWrap = 50;     
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = 'Here is the subject';
            $mail->Body    = 'Here is your token: '.$token;
                            
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
          
            if(!$mail->send()) {
                echo 'Message could not be sent.';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
            else{
                echo "<script>window.addEventListener('load', 
                function() { 
                    $('#myModal').modal('show');
                }, false);</script>" ;
             }
        }
    }
    elseif (isset($_GET['save'])) {
        $ubname=$_SESSION['ubitname'];
        $otp = $_GET['token'];
        $sql=("SELECT * FROM tbl_student_signup where ubitname = '$ubname' and token='$otp'");
        $result=mysqli_query($conn,$sql);
       
        if ($result->num_rows==1)
        {
            $did=$_SESSION['did'];
           $a= "SELECT MIN(SPLIT_FILE_ID) AS ID FROM `tbl_splitted_datasets` WHERE UBIT_NAME='' and USER_TOKEN_ID=''";
           $ra=mysqli_query($conn,$a);
            $b=0;
           while($row = $ra->fetch_assoc()) {
           $b=$row['ID'];
      
        }
            $s=("UPDATE tbl_splitted_datasets set UBIT_NAME='$ubname' ,user_token_id='$otp',FILE_ASSIGNED_TIME=CURRENT_TIMESTAMP WHERE DATASET_ID='$did' and SPLIT_FILE_ID='$b'");
            $re=mysqli_query($conn,$s);
        }
        else{
            echo "could not find";
       } 
                
    }
 }
    ?>
        
</body>

</html>