<?php

//require 'PHPMailerAutoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "csdr";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    //please try again later
}
else
{
    $ubitname = $_POST['ubitname'];

    $result = mysql_query("SELECT token FROM tbl_student_signup");
    while ($otp = mysql_fetch_array($result)) 
    {
    $text = $row['msg'];  
    }
    $ubitname=$_POST['ubitname'];
    $ubitmail=$ubitname.'@buffalo.edu';
    $otp = $_POST['otp'];
    echo $otp;

    if($token==$otp)
    {
        header("Location: http://www.google.com/");
    }
    else{
            echo 'the token you entered is incorrect';
        }
             
                
    }
 

?>