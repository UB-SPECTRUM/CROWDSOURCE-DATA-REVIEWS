
<!DOCTYPE html>

<head>
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/header.css">
  <script src="js/jquery.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.js"></script>
  <link rel="icon"  href="img/favicon.png" />
</head>

<body>
  <a href="https://www.ubspectrum.com/" target="blank">
    <div class="flip-card" >
        <div class="flip-card-inner">
            <div class="flip-card-front">
                 <img src="img/logo.png" alt="Avatar" style="width:200px;height:200px;">
            </div>
            <div class="flip-card-back">
                 <p>THE INDEPENDENT STUDENT PUBLICATION OF THE UNIVERSITY AT BUFFALO, SINCE 1950</p>
            </div>
        </div>
    </div>
</a>
  <div id="jumbo">
      <div id="textInJumbo">
        <h1>CrowdSource Data Reviews</h1> 
        <p>THE LESS YOU KNOW THE MORE YOU BELIEVE.</p> 
      </div>
  </div>
</body>

</html>