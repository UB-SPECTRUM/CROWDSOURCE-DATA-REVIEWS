<?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "csdr";

    $conn = new mysqli($servername, $username, $password,$dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else{
        $sql = "SELECT * FROM tbl_current_dataset";
        $result = $conn->query($sql);
        $datasets = array();   
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                //echo "<br> id: ". $row["DATASET_ID"]. " - DATASET Name: ". $row["DATASET_NAME"]. " " . $row["DATASET_DESCRIPTION"]. "  " .'<a href= "http://localhost/saa/studentSignUp.php">view </a>'."<br>";
                $datasets[] = $row;
            }
            $_SESSION['datasets']=$datasets;
           // echo sizeof($datasets);
        } else {
            echo "0 results";
        }
    }
?>


<html>
    <head>
        <link rel = stylesheet/css href="css/bootstrap.css" >
    </head>


    
    <body>
    <?php include "header.php";?>
    
    <div class="container">
    <div class="row col-lg-12">
        <?php        
        for($i=0;$i<sizeof($datasets);$i++){
            $name=$datasets[$i]["DATASET_NAME"];
            $description=$datasets[$i]["DATASET_DESCRIPTION"];
            $id=$datasets[$i]["DATASET_ID"];
        ?>
        
        <div class="col-sm-4">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo $name?></h5>
                <p class="card-text"><?php echo $description ?></p>
                
                <a  href=<?php echo "studentSignUp.php?datasetname=".$name."&amp;datasetdescription=".$description."&amp;datasetid=".$id?>
                    class="btn btn-primary">
                    View
                 </a>
            </div>
            </div>
        
        </div>
        

        
        <?php }         
            ?>
            </div>
     </div>  
     <?php include "footer.php";?> 
    </body>
     


 </html>