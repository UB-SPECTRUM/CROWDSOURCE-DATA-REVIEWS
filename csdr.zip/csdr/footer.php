
<footer class="page-footer font-small " id="footer">
  <div class="footer-copyright text-center py-3"> The Spectrum © ,2019. All rights reserved.
    <a href="https://www.ubspectrum.com/"> UB SPECTRUM</a>
  </div>
</footer>