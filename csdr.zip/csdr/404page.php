<html>
<head>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<?php include "header.php";?>   
<div class="jumbotron">
  <h1 class="display-4">Error 404</h1>
  <p class="lead">Oops! We can't find the page you are looking for</p>
  <hr class="my-4">
  <a class="btn btn-primary btn" href="#" role="button">Home page</a>
  </p>
</div>
<?php include "footer.php";?> 
</body>
</html>
