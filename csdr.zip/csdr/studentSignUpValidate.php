<?php
require 'PHPMailerAutoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "csdr";

$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    //please try again later
}
 else{

    $ubitname=$_GET['ubitname'];
    if (isset($_GET['Publish'])) {
    $ubitmail=$ubitname.'@buffalo.edu';
    $Generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $token= substr(str_shuffle($Generator),0,5);
    $ubittoken= $ubitname.$token;
   
    $sql = "INSERT INTO tbl_student_signup VALUES ('$ubitname','$token','$ubitmail','$ubittoken')";
    if($conn->query($sql)){
        //send mail
    $mail = new PHPMailer;

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'nallusowmith@gmail.com';                 // SMTP username
    $mail->Password = 'sowmith619';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted

    $mail->From = 'nallusowmith6@gmail.com';
    $mail->FromName = 'Ub Spectrum';
    $mail->addAddress(''.$ubitmail);     // Add a recipient
    //$mail->addAddress(''.$ubitmail);               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    $mail->WordWrap = 50;     
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body'.$token;
                    
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    

    if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
        
    }
    else{ 
        header("Location: http://localhost/saa/studentSignUp.php?ubitname=".$ubitname); 
       
    };
}
    }
    elseif (isset($_GET['Save'])) {

        $otp = $_GET['token'];
     
       

        $sql=("SELECT token FROM tbl_student_signup where ubitname = '$ubitname'");
        $result=mysqli_query($conn,$sql);
        if ($result->num_rows>0)
        {
           echo "found";
        }
        else{
            echo "could not find";
       } 
                
    }
 
    }

?>